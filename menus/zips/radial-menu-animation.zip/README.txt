A Pen created at CodePen.io. You can find this one at https://codepen.io/mudrenok/pen/xqzxoz.

 <img src="https://media.giphy.com/media/3ohzdZEgLJWjKH8J3y/giphy.gif" height="160" width="160"/>

<a href="https://dribbble.com/shots/3377940-Home-Budget-App-Interactions">Dribbble Shot</a> by tubikstudio