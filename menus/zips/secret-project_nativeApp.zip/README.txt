A Pen created at CodePen.io. You can find this one at https://codepen.io/khadkamhn/pen/BNwxEa.

 **Secret UI Project** is prototype mockups created by  [Anton Aheichanka](https://dribbble.com/madebyanton "Author") that has been converted into web version. Here is the original link of 
[Website](http://www.invisionapp.com/do "InvisionApp") &
[Dribbble](https://dribbble.com/shots/1928064-Secret-Project "Dribbble  Shot")