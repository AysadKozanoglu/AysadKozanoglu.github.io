A Pen created at CodePen.io. You can find this one at https://codepen.io/jasonhowmans/pen/dykhL.

 Here's an easy way to create an iOS style, side sliding menu.