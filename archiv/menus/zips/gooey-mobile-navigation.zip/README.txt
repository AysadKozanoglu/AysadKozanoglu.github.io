A Pen created at CodePen.io. You can find this one at https://codepen.io/Bjurhager/pen/jPLJyX.

 The cool gooey effect applied to a mobilestyle menu. Jquery and CSS Transitions for the animations.